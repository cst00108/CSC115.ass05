import java.util.NoSuchElementException;

/*
 * The shell of the class, to be completed as part
 * of CSC115 Assignment 5: Emergency Room.
 */
 */

@SuppressWarnings({"unchecked"})

/*
 * Complete this class as per the Heap.html specification document.
 * Fill in any of the parts that have the comment:
 *	/********  COMPLETE *******/
 * Do not change method headers or code that has been supplied.
 * Delete all messages to you, including this one, before submitting.
 */

public class Heap {

	private Comparable[] heapArray;;

	public Heap() {
 	/********  COMPLETE *******/
	}


 	/********  COMPLETE *******/
	

}
