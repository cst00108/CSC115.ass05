import java.util.NoSuchElementException;

/*
 * The shell of the class, to be completed as part of the
 * CSC115 Assignment 5 : Emergency Room
 */

/*
 * Complete this class as per the Heap.html specification document.
 * Fill in any of the parts that have the comment:
 *	/********  COMPLETE *******/
 * Do not change method headers or code that has been supplied.
 * Delete all messages to you, including this one, before submitting.
 */

public class PriorityQueue {
	
	private Heap heap;

	public PriorityQueue() {
 	/********  COMPLETE *******/
	}

 	/********  COMPLETE *******/
			
}
	
